import json
import time
import random
import redis

r = redis.Redis(host='localhost', port=6379, decode_responses=True)

def generate_telemetry():
    return {
        "rpm": random.randint(800, 6000),
        "oil_temp": round(random.uniform(70.0, 120.0), 2),
        "speed": random.randint(0, 150),
        "timestamp": time.time()
    }

if __name__ == "__main__":
    print("Producer started. Sending telemetry to watchdog_stream every 0.5s...")
    try:
        while True:
            data = generate_telemetry()
            r.xadd("watchdog_stream", {"data": json.dumps(data)})
            print(f"Produced: {data}")
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\nProducer stopped.")
