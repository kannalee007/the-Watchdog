import json
import asyncio
import random
import httpx
import redis.asyncio as redis
from rich.console import Console
from rich.theme import Theme

custom_theme = Theme({
    "normal": "dim green",
    "warning": "bold yellow",
    "critical": "bold red",
    "info": "cyan",
    "ai_diagnostic": "bold yellow"
})

console = Console(theme=custom_theme)


def evaluate_telemetry(data):
    rpm = data.get("rpm", 0)
    oil_temp = data.get("oil_temp", 0)

    if rpm > 5500 or oil_temp > 115:
        severity = random.choice(["WARNING", "CRITICAL"])
        return severity
    return None


async def get_ai_diagnostic(telemetry_data):
    rpm = telemetry_data.get("rpm")
    oil_temp = telemetry_data.get("oil_temp")
    speed = telemetry_data.get("speed")

    prompt = f"You are an AI mechanic monitoring a motorcycle. An anomaly was detected: RPM {rpm}, Oil Temp {oil_temp}°C, Speed {speed} km/h. In exactly one short sentence, state the mechanical risk and the immediate action required."

    payload = {
        "model": "qwen2.5:7b",
        "prompt": prompt,
        "stream": False
    }

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post("http://localhost:11434/api/generate", json=payload)
            response.raise_for_status()
            result = response.json()
            return result.get("response", "AI diagnostic unavailable.").strip()
    except Exception as e:
        return f"AI diagnostic error: {str(e)}"


async def consume():
    r = redis.Redis(host='localhost', port=6379, decode_responses=True)
    console.print("[info]Watchdog Consumer started. Monitoring watchdog_stream...[/info]")

    last_id = '0'

    try:
        while True:
            messages = await r.xread({"watchdog_stream": last_id}, count=1, block=1000)

            if messages:
                for stream_name, entries in messages:
                    for message_id, data in entries:
                        last_id = message_id
                        payload = json.loads(data.get("data", "{}"))

                        severity = evaluate_telemetry(payload)

                        if severity:
                            style = "critical" if severity == "CRITICAL" else "warning"
                            console.print("\n")
                            console.print("=" * 60, style=style)
                            console.print(f"[{severity} ANOMALY DETECTED]", style=style)
                            console.print("=" * 60, style=style)
                            console.print(f"RPM: {payload.get('rpm')} (threshold: 5500)", style=style)
                            console.print(f"Oil Temp: {payload.get('oil_temp')}°C (threshold: 115°C)", style=style)
                            console.print(f"Speed: {payload.get('speed')} km/h", style=style)
                            console.print("=" * 60, style=style)

                            ai_diagnosis = await get_ai_diagnostic(payload)
                            console.print(f"\n[AI DIAGNOSTIC] {ai_diagnosis}", style="ai_diagnostic")
                            console.print("\n")
                        else:
                            console.print(
                                f"[normal]OK | RPM: {payload.get('rpm'):4d} | Oil: {payload.get('oil_temp'):5.1f}°C | Speed: {payload.get('speed'):3d} km/h[/normal]"
                            )

            await asyncio.sleep(0.1)
    except KeyboardInterrupt:
        console.print("\n[info]Consumer stopped.[/info]")
    finally:
        await r.close()


if __name__ == "__main__":
    try:
        asyncio.run(consume())
    except KeyboardInterrupt:
        pass
